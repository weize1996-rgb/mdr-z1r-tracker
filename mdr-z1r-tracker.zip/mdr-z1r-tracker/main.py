import time
from sources.shopee import search_shopee
from filter import is_valid, is_used, seen_before
from notify import send_line
from ai_filter import update_price, is_good_deal, is_scam, avg_price

TARGET = 30000

def run():
    items = search_shopee()

    for item in items:
        price = item["price"]

        update_price(price)

        if not is_valid(item):
            continue

        if is_scam(item["title"], price):
            continue

        good = is_good_deal(price)

        if (price < TARGET or good) and not seen_before(item["id"]):
            used_tag = "二手" if is_used(item) else "新品"
            avg = avg_price()

            msg = f"""🔥 撿到機會！
💰 {price}（平均 {int(avg) if avg else '?'}）
📦 {used_tag}
📝 {item['title']}
🔗 {item['url']}"""

            send_line(msg)

while True:
    try:
        run()
    except Exception as e:
        print("error:", e)

    time.sleep(1800)