price_history = []

def update_price(price):
    price_history.append(price)
    if len(price_history) > 50:
        price_history.pop(0)

def avg_price():
    if not price_history:
        return None
    return sum(price_history) / len(price_history)

def is_good_deal(price):
    avg = avg_price()
    if not avg:
        return False
    return price < avg * 0.9  # 低於市場 10%

def is_scam(title, price):
    name = title.lower()

    if price < 15000:
        return True

    scam_words = ["模型","展示","空盒","假","replica"]
    return any(w in name for w in scam_words)